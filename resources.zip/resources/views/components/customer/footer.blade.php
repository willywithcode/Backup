<!-- Footer -->
<footer>
    <div class="footer-bottom">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 col-xs-12 coppyright text-center">© 2023 Shoe Addict, All rights reserved.
                </div>
            </div>
        </div>
    </div>
</footer>
